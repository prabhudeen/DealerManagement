import { DatefilterpipePipe } from './datefilterpipe.pipe';

describe('DatefilterpipePipe', () => {
  it('create an instance', () => {
    const pipe = new DatefilterpipePipe();
    expect(pipe).toBeTruthy();
  });
});
