export class EventConstants {

    public static readonly IP: string = '10.64.217.120';
    public static readonly PORT: string = '8090';
    public static readonly PROTOCOL: string = 'http://';
    public static readonly CONTEXT: string = '';
  
  }
  