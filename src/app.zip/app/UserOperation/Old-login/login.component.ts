import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-old',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
